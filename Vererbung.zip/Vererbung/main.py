class Fahrzeuge:
    def __init__(self, marke, modell, baujahr):
        self.marke = marke
        self.modell = modell
        self.baujahr = baujahr

    def __str__(self):
        return f"{self.marke} {self.modell} aus dem Jahr {self.baujahr}"

class Auto(Fahrzeuge):
    def __init__(self, marke, modell, baujahr, turen):
        super().__init__(marke, modell, baujahr)
        self.turen = turen

    def __str__(self):
        return f"{super().__str__()} mit {self.turen} Türen"

class Motorrad(Fahrzeuge):
    def __init__(self, marke, modell, baujahr, ps):
        super().__init__(marke, modell, baujahr)
        self.ps = ps

    def __str__(self):
        return f"{super().__str__()} mit {self.ps} PS"

class Fahrrad(Fahrzeuge):
    def __init__(self, marke, modell, baujahr, art):
        super().__init__(marke, modell, baujahr)
        self.art = art

    def __str__(self):
        return f"{super().__str__()}, Typ: {self.art}"

if __name__ == "__main__":
    auto = Auto("Audi", "RS7", 2020, 4)
    motorrad = Motorrad("Yamaha", "MT-07", 2019, 215)
    fahrrad = Fahrrad("Cube", "Stereo", 2022, "Mountainbike")

    print(auto)
    print(motorrad)
    print(fahrrad)
